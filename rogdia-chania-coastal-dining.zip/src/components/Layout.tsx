import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";

export const RESERVE_PHONE = "+30 28210 00000";

const nav = [
  { to: "/", label: "Αρχική" },
  { to: "/menu", label: "Μενού" },
  { to: "/gallery", label: "Φωτογραφίες" },
  { to: "/reservations", label: "Κρατήσεις" },
  { to: "/contact", label: "Επικοινωνία" },
] as const;

export function Header({ overlay = false }: { overlay?: boolean }) {
  return (
    <header className={`${overlay ? "absolute text-ink-foreground" : "relative bg-ink text-ink-foreground"} inset-x-0 top-0 z-20`}>
      <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-between gap-4 px-6 py-5">
        <Link to="/" className="flex items-center gap-3">
          <span className="grid h-12 w-12 place-items-center rounded-full border border-gold font-display text-xl text-gold">Ρ</span>
          <span className="font-display text-2xl tracking-wide">Ρόγδια</span>
        </Link>
        <nav className="flex flex-wrap gap-5 text-xs uppercase tracking-[0.2em]">
          {nav.map((n) => (
            <Link key={n.to} to={n.to} className="opacity-80 transition hover:text-gold hover:opacity-100" activeProps={{ className: "text-gold opacity-100" }} activeOptions={{ exact: true }}>
              {n.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}

export function Footer() {
  return (
    <footer className="bg-ink text-ink-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-14 md:grid-cols-3">
        <div>
          <p className="font-display text-3xl">Ρόγδια</p>
          <p className="mt-2 text-sm opacity-70">Κρητική κουζίνα στο Ενετικό Λιμάνι των Χανίων</p>
        </div>
        <div className="text-sm opacity-80">
          <p className="eyebrow mb-3">Ωράριο</p>
          <p>Καθημερινά 12:00 – 00:00</p>
        </div>
        <div className="text-sm opacity-80">
          <p className="eyebrow mb-3">Επικοινωνία</p>
          <p>Ενετικό Λιμάνι, Χανιά 731 32</p>
          <p>{RESERVE_PHONE}</p>
          <p>info@rogdia.gr</p>
        </div>
      </div>
      <p className="border-t border-ink-foreground/10 py-5 text-center text-xs opacity-50">© {new Date().getFullYear()} Ρόγδια Χανιά</p>
    </footer>
  );
}

export function PageHero({ title, subtitle, image }: { title: string; subtitle: string; image: string }) {
  return (
    <section className="relative flex h-[55vh] min-h-[380px] items-end">
      <img src={image} alt="" className="absolute inset-0 h-full w-full object-cover" />
      <div className="absolute inset-0 bg-overlay" />
      <Header overlay />
      <div className="relative mx-auto w-full max-w-7xl px-6 pb-14 text-ink-foreground">
        <p className="eyebrow">{subtitle}</p>
        <h1 className="mt-3 text-5xl md:text-7xl">{title}</h1>
      </div>
    </section>
  );
}

export function Shell({ children }: { children: ReactNode }) {
  return <div className="min-h-screen">{children}<Footer /></div>;
}

export function meta(title: string, description: string) {
  return [
    { title },
    { name: "description", content: description },
    { property: "og:title", content: title },
    { property: "og:description", content: description },
    { property: "og:type", content: "website" },
    { name: "twitter:card", content: "summary_large_image" },
  ];
}
