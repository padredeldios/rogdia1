import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import pom from "@/assets/pomegranate.jpg";
import { PageHero, Shell, meta, RESERVE_PHONE } from "@/components/Layout";

export const Route = createFileRoute("/reservations")({
  head: () => ({ meta: meta("Κρατήσεις — Ρόγδια Χανιά", "Κλείστε τραπέζι στην ταβέρνα Ρόγδια στο Ενετικό Λιμάνι των Χανίων.") }),
  component: Reservations,
});

const field = "w-full border border-input bg-card px-4 py-3 outline-none focus:border-primary";

function Reservations() {
  const [sent, setSent] = useState(false);
  return (
    <Shell>
      <PageHero title="Κρατήσεις" subtitle="Κλείστε τραπέζι" image={pom} />
      <div className="mx-auto max-w-2xl px-6 py-24">
        {sent ? (
          <div className="text-center">
            <h2 className="text-4xl text-primary">Ευχαριστούμε!</h2>
            <p className="mt-4 text-muted-foreground">Λάβαμε το αίτημά σας και θα επικοινωνήσουμε μαζί σας για επιβεβαίωση.</p>
          </div>
        ) : (
          <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} className="grid gap-4 md:grid-cols-2">
            <input required placeholder="Ονοματεπώνυμο" className={`${field} md:col-span-2`} />
            <input required type="tel" placeholder="Τηλέφωνο" className={field} />
            <input type="email" placeholder="Email" className={field} />
            <input required type="date" className={field} />
            <input required type="time" className={field} />
            <select required className={`${field} md:col-span-2`} defaultValue="">
              <option value="" disabled>Άτομα</option>
              {Array.from({ length: 12 }, (_, i) => <option key={i}>{i + 1}</option>)}
            </select>
            <textarea placeholder="Σχόλια" rows={3} className={`${field} md:col-span-2`} />
            <button className="bg-primary py-4 text-xs uppercase tracking-[0.25em] text-primary-foreground md:col-span-2">Αποστολή κράτησης</button>
            <p className="text-center text-sm text-muted-foreground md:col-span-2">ή καλέστε μας στο {RESERVE_PHONE}</p>
          </form>
        )}
      </div>
    </Shell>
  );
}
