import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import food from "@/assets/food.jpg";
import interior from "@/assets/interior.jpg";
import pom from "@/assets/pomegranate.jpg";
import { PageHero, Shell, meta } from "@/components/Layout";

export const Route = createFileRoute("/gallery")({
  head: () => ({ meta: meta("Φωτογραφίες — Ρόγδια Χανιά", "Δείτε τον χώρο, τα πιάτα και τη θέα της ταβέρνας Ρόγδια.") }),
  component: Gallery,
});

const photos = [hero, interior, food, pom];

function Gallery() {
  return (
    <Shell>
      <PageHero title="Φωτογραφίες" subtitle="Ο χώρος μας" image={interior} />
      <div className="mx-auto grid max-w-7xl gap-4 px-6 py-24 md:grid-cols-2">
        {photos.map((p, i) => (
          <img key={i} src={p} alt="" loading="lazy" className="aspect-[4/3] w-full object-cover transition duration-500 hover:scale-[1.02]" />
        ))}
      </div>
    </Shell>
  );
}
