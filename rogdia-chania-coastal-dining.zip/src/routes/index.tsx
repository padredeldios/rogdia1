import { createFileRoute, Link } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import food from "@/assets/food.jpg";
import interior from "@/assets/interior.jpg";
import pom from "@/assets/pomegranate.jpg";
import { Header, Shell, meta } from "@/components/Layout";

export const Route = createFileRoute("/")({
  head: () => ({ meta: meta("Ρόγδια Χανιά — Κρητική ταβέρνα στο Ενετικό Λιμάνι", "Αυθεντική κρητική κουζίνα με θέα στον φάρο των Χανίων. Κάντε κράτηση τραπεζιού.") }),
  component: Index,
});

function Index() {
  return (
    <Shell>
      <section className="relative flex h-screen min-h-[600px] items-center justify-center text-center">
        <img src={hero} alt="Η ταβέρνα Ρόγδια στο λιμάνι των Χανίων" width={1920} height={1088} className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-overlay" />
        <Header overlay />
        <div className="relative px-6 text-ink-foreground">
          <p className="eyebrow">Χανιά · Κρήτη</p>
          <h1 className="mt-4 text-7xl md:text-9xl">Ρόγδια</h1>
          <p className="mt-4 text-lg opacity-90">Μια γαστρονομική εμπειρία στο Ενετικό Λιμάνι</p>
          <div className="mt-10 flex flex-wrap justify-center gap-4">
            <Link to="/reservations" className="bg-primary px-8 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground transition hover:bg-primary/85">Κράτηση</Link>
            <Link to="/menu" className="border border-ink-foreground/70 px-8 py-3 text-xs uppercase tracking-[0.25em] transition hover:border-gold hover:text-gold">Μενού</Link>
          </div>
        </div>
        <p className="absolute bottom-8 right-8 hidden text-right font-display text-xl text-ink-foreground md:block">Ανοιχτά καθημερινά<br />από τις 12:00</p>
      </section>

      <section className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-24 md:grid-cols-2">
        <img src={interior} alt="Εσωτερικός χώρος" loading="lazy" width={960} height={1280} className="aspect-[4/5] w-full object-cover" />
        <div>
          <p className="eyebrow">Η ιστορία μας</p>
          <h2 className="mt-3 text-5xl">Ρόγδι, το φρούτο της φιλοξενίας</h2>
          <p className="mt-6 leading-relaxed text-muted-foreground">Στην καρδιά του παλιού λιμανιού, μέσα σε ένα πέτρινο κτίριο με ενετικές καμάρες, σερβίρουμε την Κρήτη όπως τη μάθαμε: τοπικά προϊόντα, αγνό ελαιόλαδο, ρακή και πολύ κέφι.</p>
          <Link to="/gallery" className="mt-8 inline-block border-b border-primary pb-1 text-xs uppercase tracking-[0.25em] text-primary">Δείτε τον χώρο</Link>
        </div>
      </section>

      <section className="bg-ink text-ink-foreground">
        <div className="mx-auto grid max-w-7xl items-center gap-12 px-6 py-24 md:grid-cols-2">
          <div className="md:order-2"><img src={food} alt="Κρητικά πιάτα" loading="lazy" width={1280} height={960} className="w-full object-cover" /></div>
          <div>
            <p className="eyebrow">Κουζίνα</p>
            <h2 className="mt-3 text-5xl">Γεύσεις από τη γη και τη θάλασσα</h2>
            <p className="mt-6 leading-relaxed opacity-75">Ντάκος, χταπόδι στα κάρβουνα, αρνί με σταμναγκάθι και φρέσκα ψάρια της ημέρας.</p>
            <Link to="/menu" className="mt-8 inline-block bg-primary px-8 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground">Το μενού μας</Link>
          </div>
        </div>
      </section>

      <section className="relative flex min-h-[70vh] items-center justify-center text-center">
        <img src={pom} alt="" loading="lazy" className="absolute inset-0 h-full w-full object-cover" />
        <div className="absolute inset-0 bg-overlay" />
        <div className="relative px-6 text-ink-foreground">
          <p className="eyebrow">Ηλιοβασίλεμα στο λιμάνι</p>
          <h2 className="mt-3 text-5xl md:text-6xl">Κλείστε το τραπέζι σας</h2>
          <Link to="/reservations" className="mt-10 inline-block bg-primary px-8 py-3 text-xs uppercase tracking-[0.25em] text-primary-foreground">Κράτηση</Link>
        </div>
      </section>
    </Shell>
  );
}
