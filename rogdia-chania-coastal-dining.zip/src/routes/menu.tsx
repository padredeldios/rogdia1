import { createFileRoute } from "@tanstack/react-router";
import food from "@/assets/food.jpg";
import { PageHero, Shell, meta } from "@/components/Layout";

export const Route = createFileRoute("/menu")({
  head: () => ({ meta: meta("Μενού — Ρόγδια Χανιά", "Ορεκτικά, κυρίως πιάτα, θαλασσινά και γλυκά της κρητικής κουζίνας.") }),
  component: Menu,
});

const sections = [
  { title: "Ορεκτικά", items: [["Ντάκος", "Κριθαροκουλούρα, ντομάτα, μυζήθρα, ρίγανη", "7,50"], ["Σταμναγκάθι", "Βραστό με ελαιόλαδο και λεμόνι", "8,00"], ["Καλιτσούνια", "Με μυζήθρα και δυόσμο", "7,00"], ["Σαλάτα Ρόγδια", "Χόρτα, ρόδι, γραβιέρα, καρύδια", "9,50"]] },
  { title: "Κυρίως", items: [["Αρνί με σταμναγκάθι", "Αργομαγειρεμένο, λεμονάτο", "18,00"], ["Κόκορας με χυλοπίτες", "Παραδοσιακή συνταγή", "16,00"], ["Σφακιανή πίτα", "Με μέλι θυμαρίσιο", "8,50"], ["Γαμοπίλαφο", "Χανιώτικο, με ζωμό κρέατος", "15,00"]] },
  { title: "Θάλασσα", items: [["Χταπόδι στα κάρβουνα", "Με φάβα και κάπαρη", "16,50"], ["Καλαμαράκια", "Τηγανητά", "12,00"], ["Ψάρι ημέρας", "Τιμή ανά κιλό", "—"]] },
  { title: "Γλυκά & Ποτά", items: [["Ξεροτήγανα", "Με μέλι και σουσάμι", "6,00"], ["Ρακή (καραφάκι)", "", "5,00"], ["Κρητικό κρασί", "Ποτήρι", "5,50"]] },
];

function Menu() {
  return (
    <Shell>
      <PageHero title="Μενού" subtitle="Κρητική κουζίνα" image={food} />
      <div className="mx-auto grid max-w-5xl gap-16 px-6 py-24 md:grid-cols-2">
        {sections.map((s) => (
          <div key={s.title}>
            <h2 className="border-b border-border pb-3 text-3xl text-primary">{s.title}</h2>
            <ul className="mt-6 space-y-5">
              {s.items.map(([n, d, p]) => (
                <li key={n}>
                  <div className="flex items-baseline justify-between gap-4"><span className="font-display text-xl">{n}</span><span className="text-sm text-primary">{p === "—" ? p : `€${p}`}</span></div>
                  {d && <p className="text-sm text-muted-foreground">{d}</p>}
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </Shell>
  );
}
