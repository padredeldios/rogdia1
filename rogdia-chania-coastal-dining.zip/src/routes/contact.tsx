import { createFileRoute } from "@tanstack/react-router";
import hero from "@/assets/hero.jpg";
import { PageHero, Shell, meta, RESERVE_PHONE } from "@/components/Layout";

export const Route = createFileRoute("/contact")({
  head: () => ({ meta: meta("Επικοινωνία — Ρόγδια Χανιά", "Διεύθυνση, τηλέφωνο, ωράριο και χάρτης για την ταβέρνα Ρόγδια.") }),
  component: Contact,
});

function Contact() {
  return (
    <Shell>
      <PageHero title="Επικοινωνία" subtitle="Βρείτε μας" image={hero} />
      <div className="mx-auto grid max-w-7xl gap-12 px-6 py-24 md:grid-cols-[1fr_2fr]">
        <div className="space-y-8">
          <div><p className="eyebrow">Διεύθυνση</p><p className="mt-2 font-display text-2xl">Ενετικό Λιμάνι<br />Χανιά 731 32</p></div>
          <div><p className="eyebrow">Τηλέφωνο</p><p className="mt-2 font-display text-2xl">{RESERVE_PHONE}</p></div>
          <div><p className="eyebrow">Ωράριο</p><p className="mt-2 font-display text-2xl">Καθημερινά 12:00 – 00:00</p></div>
        </div>
        <iframe title="Χάρτης" src="https://www.google.com/maps?q=Venetian+Harbour+Chania&output=embed" className="h-[450px] w-full border-0" loading="lazy" />
      </div>
    </Shell>
  );
}
